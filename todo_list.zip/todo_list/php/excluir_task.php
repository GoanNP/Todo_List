<?php

    $id = $_POST['id_task'];

    $con = mysqli_connect("localhost:3306", 'todo_user', 'todo_user', "todo_list");

    $mensagem = "";

    $delete = "DELETE FROM tasks WHERE id = $id";

    mysqli_query($con, $delete);

    $mensagem = "Task excluído com sucesso.";

    $json = json_encode($mensagem);

    echo $json;
?>
<?php

    $con = mysqli_connect("localhost:3306", 'todo_user', 'todo_user', "todo_list");

    $resultado = mysqli_query($con, "SELECT * from tasks");

    $dados = array();

    while($registro = mysqli_fetch_assoc($resultado)) {

        array_push($dados, $registro);
    }

    $json = json_encode($dados);
    echo $json;
?>
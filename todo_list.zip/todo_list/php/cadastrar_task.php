<?php

    $title = $_POST['title'];
    $description = $_POST['description'];
    
    $con = mysqli_connect('localhost:3306', 'todo_user', 'todo_user', 'todo_list');

    $query = "INSERT INTO tasks (title, description_) VALUES ('$title', '$description')";

    mysqli_query($con, $query);

    $resposta = "Cadastro da task realizado com sucesso.";

    $json = json_encode($resposta);
    echo $json;
    
?>
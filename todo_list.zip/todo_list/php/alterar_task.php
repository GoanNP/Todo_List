<?php

    $title = $_POST['title'];
    $description = $_POST['description'];
    $id = $_POST['id'];
    
    $con = mysqli_connect('localhost:3306', 'todo_user', 'todo_user', 'todo_list');

    $title = mysqli_real_escape_string($con, $title);
    $description = mysqli_real_escape_string($con, $description);
    $id = (int) $id;

    $query = "UPDATE tasks SET title = '$title', description_ = '$description' WHERE id = $id";

    mysqli_query($con, $query);

    $resposta = "Update da task realizado com sucesso.";

    $json = json_encode($resposta);
    echo $json;
    
?>
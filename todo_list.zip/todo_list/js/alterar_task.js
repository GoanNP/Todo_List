async function mudar_pagina(id) {
    var conteudo = `
    <div class="cadastrar">
        <form id="form-alterar">

            <div class="input-form">
            <h1>
                Alterar Task
            </h1>
            </div>

            <div class="input-form">
                <i class="fa-regular fa-user"></i>
                <input type="text" placeholder="Nome da Task" id="title" name="title" maxlength="255"/>
            </div>

            <div class="input-form">
                <i class="fa-regular fa-user"></i>
                <input type="text" placeholder="Descrição" id="description" name="description"/>
            </div>

            <div class="input-form">
                <button type="button" onclick="alterar_task(${id})"> Alterar Task </button>
            </div>

        </form>
    </div>`;

    localStorage.setItem('conteudo', conteudo);

    window.location.href = "html/alterar_task.html";
}


async function alterar_task(id){

    var form = document.getElementById('form-alterar');
    var dados = new FormData(form);

    var title = document.getElementById('title').value;
    var description = document.getElementById('description').value;
    
    if(title === "" || description === ""){

    }

    else {
        dados.append('id', id);

        var promise = await fetch("../../todo_list/php/alterar_task.php", {
            method: "POST",
            body: dados
        });

        var resultado = await promise.json();

        localStorage.removeItem('conteudo');

        window.location.href = "../index.html";
    }
}
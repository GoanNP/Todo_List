window.onload = async function() {
    var resultado = await fetch("../../todo_list/php/get_task.php", {
        method: "GET"
    });

    var dados = await resultado.json();

    if (dados.length == 0){

        var conteudo = `
        <div class="card">
            <div class="add">
                <a href="html/cadastro_task.html"> + Adicionar Task </a>
            </div>
        </div>`;

        document.getElementById('tasks').innerHTML += conteudo;
    } 
    else {
        for (var i = 0; i < dados.length; i++) {

        var conteudo = `
        <div class="card">
            <div class="card-title">
                ${dados[i].title}
            </div>

            <div class="card-description">
                ${dados[i].description_}
            </div>

            <div class="card-button-edit">
                <button type="button" class="button-edit" onclick="mudar_pagina(${dados[i].id})"> Editar Task </button>
            </div>

            <div class="card-button-remove">
                <button type="button" class="button-remove" onclick="excluir_task(${dados[i].id})"> Remover Task </button>
            </div>
        </div>`;

        document.getElementById('tasks').innerHTML += conteudo;
        }
    }
}

async function excluir_task(id) {
    var dados = new FormData();
    dados.append("id_task", id);

    await fetch("../../todo_list/php/excluir_task.php", {
        method: "POST",
        body: dados
    });

    location.reload();
}
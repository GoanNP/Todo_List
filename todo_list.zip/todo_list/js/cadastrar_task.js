async function cadastrar_task(){

    var form = document.getElementById('form-cadastro');
    var dados = new FormData(form);

    var title = document.getElementById('title').value;
    var description = document.getElementById('description').value;

    if(title === "" || description === ""){

        
    }

    else {

        var promise = await fetch("../../todo_list/php/cadastrar_task.php", {
            method: "POST",
            body: dados
        });

        var resultado = await promise.json();

        window.location.href = "../index.html";
    }
}